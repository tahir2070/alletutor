(function ($) {
    "use strict";

    // Script for OffCanvas Menu Activation
    $(document).ready(function () {
        $('.toggle-bar').on('click', function () {
            $('.off-canvas-menu-wrap, .off-canvas-overlay').addClass('active');
        })

        $('.cls-off-canvas-menu').on('click', function () {
            $('.off-canvas-menu-wrap, .off-canvas-overlay').removeClass('active');
        })
    })

    $(document).ready(function(){
        $('.table-action-btns button').on('click', function(){
            $(this).toggleClass('active');
        })

        $('.user-pf > li > a').on('click', function(){
            $('.user-pf li ul.submenu').slideToggle(500);
        })

        $('.rec-btn').on('click', function(){
            $(this).toggleClass('active');
        })

        $('.weaving-had a').on('click', function(e){
            e.preventDefault();
            $(this).toggleClass('active');
        })

        $('.drawing-tool li a').on('click', function(e){
            e.preventDefault();
            $('.drawing-tool li a').removeClass('active');
            $(this).toggleClass('active');
        })
    })

    $('.sl-select').niceSelect();


  
})(jQuery);	 // End line